/// En Android esto hablaba con un servicio nativo (notificacion de progreso).
/// En escritorio no hace falta: el progreso se ve dentro de la ventana, asi
/// que estas funciones no hacen nada. Se dejan para no tocar library.dart.
class BackgroundService {
  static Future<bool> start({
    required String title,
    required String text,
    int progress = -1,
    int max = 0,
  }) async => false;

  static Future<void> update({
    required String title,
    required String text,
    required int progress,
    required int max,
  }) async {}

  static Future<void> finish({
    required String title,
    required String text,
  }) async {}

  static Future<void> stop() async {}

  static Future<void> moveToBack() async {}
}
