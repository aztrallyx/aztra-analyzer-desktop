// Llama a ffmpeg.exe / ffprobe.exe (incluidos en la carpeta "bin" junto a la
// app) en lugar de FFmpegKit, que solo existe para Android/iOS.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

class FfmpegResult {
  const FfmpegResult(this.exitCode, this.stdout, this.stderr);
  final int exitCode;
  final String stdout;
  final String stderr;
  bool get ok => exitCode == 0;
}

class FfmpegCli {
  FfmpegCli._();

  static final Set<Process> _running = <Process>{};

  /// Busca <carpeta del exe>/bin/<nombre>.exe; si no esta, usa el del PATH
  /// (solo para desarrollo).
  static String _binary(String name) {
    final exeDir = File(Platform.resolvedExecutable).parent.path;
    final sep = Platform.pathSeparator;
    final file = Platform.isWindows ? '$name.exe' : name;
    final bundled = File('$exeDir${sep}bin$sep$file');
    if (bundled.existsSync()) return bundled.path;
    return name;
  }

  static Future<FfmpegResult> ffmpeg(
    List<String> args, {
    String? workingDirectory,
  }) => _run(_binary('ffmpeg'), ['-nostdin', ...args], workingDirectory);

  /// Equivale a FFprobeKit.getMediaInformation: devuelve el JSON de ffprobe
  /// ({format: {...}, streams: [...]}) o null si no pudo leer el archivo.
  static Future<Map<String, dynamic>?> probe(String path) async {
    final r = await _run(_binary('ffprobe'), [
      '-v',
      'error',
      '-print_format',
      'json',
      '-show_format',
      '-show_streams',
      '-i',
      path,
    ], null);
    if (!r.ok) return null;
    try {
      final decoded = jsonDecode(r.stdout);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  static Future<FfmpegResult> _run(
    String exe,
    List<String> args,
    String? workingDirectory,
  ) async {
    Process p;
    try {
      p = await Process.start(exe, args, workingDirectory: workingDirectory);
    } on ProcessException catch (e) {
      throw Exception(
        'No pude iniciar FFmpeg (${e.message}). Reinstala Aztra Analyzer.',
      );
    }
    _running.add(p);
    try {
      // Se leen stdout y stderr a la vez para que el proceso no se bloquee.
      final out = p.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final err = p.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final code = await p.exitCode;
      return FfmpegResult(code, await out, await err);
    } finally {
      _running.remove(p);
    }
  }

  /// Cancela todo lo que FFmpeg este haciendo ahora mismo.
  static Future<void> cancelAll() async {
    for (final p in List<Process>.of(_running)) {
      p.kill();
    }
  }
}
