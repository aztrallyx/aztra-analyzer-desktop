// Cosas propias de Windows: ventana, confirmacion al cerrar y guardar archivos.
import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';

import 'library.dart';

/// Tamano, titulo y minimo de la ventana. Tambien evita que se cierre sola
/// para poder preguntar si hay un analisis en curso.
Future<void> initDesktopWindow() async {
  if (!Platform.isWindows) return;
  await windowManager.ensureInitialized();
  const options = WindowOptions(
    size: Size(1180, 760),
    minimumSize: Size(820, 560),
    center: true,
    title: 'Aztra Analyzer',
  );
  await windowManager.waitUntilReadyToShow(options, () async {
    await windowManager.show();
    await windowManager.focus();
  });
  await windowManager.setPreventClose(true);
}

/// Pide al usuario donde guardar y copia ahi [sourcePath].
/// Devuelve la ruta final, o null si cancelo.
Future<String?> saveCopyAs({
  required String sourcePath,
  required String suggestedName,
  required String extension,
  String? dialogTitle,
}) async {
  final dest = await FilePicker.platform.saveFile(
    dialogTitle: dialogTitle ?? 'Guardar como',
    fileName: suggestedName,
    type: FileType.custom,
    allowedExtensions: [extension],
  );
  if (dest == null) return null;
  final fixed = dest.toLowerCase().endsWith('.$extension')
      ? dest
      : '$dest.$extension';
  await File(sourcePath).copy(fixed);
  return fixed;
}

enum _CloseChoice { stay, minimize, cancel }

/// Al cerrar la ventana: si hay un analisis en curso, pregunta que hacer.
class WindowCloseGuard extends StatefulWidget {
  const WindowCloseGuard({
    super.key,
    required this.controller,
    required this.navigatorKey,
    required this.child,
  });

  final LibraryController controller;
  final GlobalKey<NavigatorState> navigatorKey;
  final Widget child;

  @override
  State<WindowCloseGuard> createState() => _WindowCloseGuardState();
}

class _WindowCloseGuardState extends State<WindowCloseGuard>
    with WindowListener {
  bool _asking = false;

  @override
  void initState() {
    super.initState();
    if (Platform.isWindows) windowManager.addListener(this);
  }

  @override
  void dispose() {
    if (Platform.isWindows) windowManager.removeListener(this);
    super.dispose();
  }

  @override
  void onWindowClose() {
    unawaited(_handleClose());
  }

  Future<void> _handleClose() async {
    if (_asking) return;
    final c = widget.controller;
    if (!c.running) {
      await windowManager.destroy();
      return;
    }
    final ctx = widget.navigatorKey.currentContext;
    if (ctx == null) {
      await windowManager.destroy();
      return;
    }
    _asking = true;
    final choice = await showDialog<_CloseChoice>(
      context: ctx,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Hay un análisis en curso'),
        content: const Text(
          'Puedes seguir analizando con la ventana minimizada, o cancelar '
          'y cerrar (lo ya analizado se conserva).',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogCtx).pop(_CloseChoice.stay),
            child: const Text('Volver'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogCtx).pop(_CloseChoice.minimize),
            child: const Text('Seguir minimizado'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogCtx).pop(_CloseChoice.cancel),
            child: const Text('Cancelar y cerrar'),
          ),
        ],
      ),
    );
    _asking = false;
    switch (choice) {
      case _CloseChoice.minimize:
        await windowManager.minimize();
      case _CloseChoice.cancel:
        await c.stop();
        // Espera (maximo 5 s) a que termine de guardar lo analizado.
        for (var i = 0; i < 50 && c.running; i++) {
          await Future<void>.delayed(const Duration(milliseconds: 100));
        }
        await windowManager.destroy();
      case _CloseChoice.stay:
      case null:
        break;
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
