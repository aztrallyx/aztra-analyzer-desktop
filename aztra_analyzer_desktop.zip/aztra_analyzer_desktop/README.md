# Aztra Analyzer 2.3 (Windows)

Version de escritorio de Aztra Analyzer, el analizador de calidad de audio.
Basado en el de Mornye (https://github.com/mornyeapp/Mornye):
`audio_analysis_ffmpeg.dart` y `audio_analysis_models.dart` son los originales
de Mornye, sin tocar su logica.

## Que cambia respecto a la version de Android
- FFmpeg ya no es FFmpegKit: la app llama a `ffmpeg.exe` y `ffprobe.exe`
  (carpeta `bin` junto al programa, builds LGPL de BtbN).
- Sin permisos ni notificaciones: el progreso se ve dentro de la ventana.
- Arrastra carpetas o canciones a la ventana para analizarlas.
- "Compartir" ahora es "Guardar como..." (CSV y espectrogramas).
- Velocidad de analisis "Automatico" (usa la mitad de los nucleos).
- Al cerrar con un analisis en curso, pregunta: volver, seguir minimizado o
  cancelar y cerrar.
- Contenido centrado con ancho maximo en ventanas grandes.

## Compilar e instalar (GitHub Actions)
1. Sube `aztra_analyzer_desktop.zip` (sin descomprimir) a la raiz del repo.
2. Sube `build.yml` a `.github/workflows/`.
3. Actions > Build Windows > Run workflow.
4. El instalador `AztraAnalyzer-Setup-*.exe` queda en Releases. Descargalo,
   ejecutalo y listo: no necesita instalar nada mas (incluye FFmpeg y las
   librerias de Visual C++).

## Licencia
LGPL-3.0 (ver LICENSE, COPYING y NOTICE). Fuentes Google Sans Flex e Inter bajo
SIL Open Font License (ver assets/licenses). FFmpeg (build LGPL de BtbN) se
distribuye en `bin/` con su licencia.
