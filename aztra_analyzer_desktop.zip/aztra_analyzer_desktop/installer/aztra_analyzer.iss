; Instalador de Aztra Analyzer (Inno Setup 6).
; Se compila desde el workflow con:
;   ISCC /DAppVersion=2.3.0 installer\aztra_analyzer.iss
#ifndef AppVersion
  #define AppVersion "2.3.0"
#endif
#define SourceDir "..\build\windows\x64\runner\Release"

[Setup]
AppId={{6F3A1B52-8C0E-4D6B-9B64-A27A00000001}
AppName=Aztra Analyzer
AppVersion={#AppVersion}
AppPublisher=aztrallyx
DefaultDirName={autopf}\Aztra Analyzer
DefaultGroupName=Aztra Analyzer
DisableProgramGroupPage=yes
OutputDir=..\dist
OutputBaseFilename=AztraAnalyzer-Setup-{#AppVersion}
SetupIconFile=..\windows\runner\resources\app_icon.ico
UninstallDisplayIcon={app}\aztra_analyzer.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Se instala solo para tu usuario: no pide permisos de administrador.
PrivilegesRequired=lowest
CloseApplications=yes

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\Aztra Analyzer"; Filename: "{app}\aztra_analyzer.exe"
Name: "{autodesktop}\Aztra Analyzer"; Filename: "{app}\aztra_analyzer.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\aztra_analyzer.exe"; Description: "Abrir Aztra Analyzer"; Flags: nowait postinstall skipifsilent
